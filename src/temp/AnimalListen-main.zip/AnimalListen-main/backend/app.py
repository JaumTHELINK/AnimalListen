"""
AnimaListen Pro - Backend Simplificado com NLP
Transcreve áudio e usa Llama para extrair informações automaticamente
"""

from datetime import datetime
from typing import Optional, List
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from starlette.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
import tempfile
import os
import json
import traceback

# Importações NLP
try:
    import whisper
    WHISPER_OK = True
except Exception as e:
    print(f"❌ Erro ao importar Whisper: {e}")
    WHISPER_OK = False

try:
    import ollama
    LLAMA_OK = True
except Exception as e:
    print(f"❌ Erro ao importar Ollama: {e}")
    LLAMA_OK = False

app = FastAPI(title="AnimaListen Pro API", version="2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dados em memória
prontuarios_db = []
internacoes_db = []
prontuario_counter = 0
internacao_counter = 0

# 🔥 CACHE DO MODELO WHISPER (carrega uma vez só)
whisper_model = None

def get_whisper_model():
    """Carrega o modelo Whisper apenas uma vez (lazy loading)"""
    global whisper_model
    if whisper_model is None:
        print("🎤 Carregando modelo Whisper (primeira vez)...")
        whisper_model = whisper.load_model("base")
        print("✅ Whisper carregado!")
    return whisper_model

# Modelos
class ProntuarioRequest(BaseModel):
    tutor_nome: Optional[str] = None
    tutor_cpf: Optional[str] = None
    tutor_telefone: Optional[str] = None
    tutor_email: Optional[str] = None
    tutor_endereco: Optional[str] = None
    animal_nome: Optional[str] = None
    animal_especie: Optional[str] = None
    animal_raca: Optional[str] = None
    animal_idade: Optional[str] = None
    animal_sexo: Optional[str] = None
    animal_peso: Optional[float] = None
    queixa_principal: Optional[str] = None
    historico_doenca: Optional[str] = None
    sintomas: Optional[List[str]] = None
    comportamento: Optional[List[str]] = None
    temperatura: Optional[float] = None
    frequencia_cardiaca: Optional[int] = None
    frequencia_respiratoria: Optional[int] = None
    mucosas: Optional[str] = None
    palpacao_abdominal: Optional[str] = None
    suspeita_diagnostica: Optional[str] = None
    exames_solicitados: Optional[List[str]] = None
    tratamento_prescrito: Optional[str] = None
    medicamentos: Optional[List[str]] = None
    observacoes_gerais: Optional[str] = None
    recomendacoes: Optional[str] = None

class InternacaoRequest(BaseModel):
    animal_nome: str
    animal_especie: Optional[str] = None
    animal_raca: Optional[str] = None
    animal_idade: Optional[str] = None
    animal_peso: Optional[float] = None
    tutor_nome: Optional[str] = None
    tutor_telefone: Optional[str] = None
    motivo: str
    status: Optional[str] = "observacao"

class RegistroRequest(BaseModel):
    tipo: str
    valor: str
    notas: Optional[str] = None

# Funções NLP
def transcrever_audio(audio_bytes: bytes) -> str:
    """Transcreve áudio usando Whisper"""
    if not WHISPER_OK:
        raise HTTPException(500, "Whisper não instalado. Use: pip install openai-whisper")
    
    print(f"📁 Recebendo áudio: {len(audio_bytes)} bytes")
    
    with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp:
        temp.write(audio_bytes)
        temp_path = temp.name
    
    try:
        print("🎤 Iniciando transcrição...")
        model = get_whisper_model()  # Usa cache
        result = model.transcribe(temp_path, language="pt")
        texto = result["text"]
        print(f"✅ Transcrito: {texto[:100]}...")
        return texto
    except Exception as e:
        print(f"❌ Erro na transcrição: {str(e)}")
        traceback.print_exc()
        raise HTTPException(500, f"Erro ao transcrever: {str(e)}")
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)

def _limpar_json_response(texto_resposta: str) -> str:
    """Remove markdown e artefatos da resposta do Llama para extrair JSON puro"""
    texto_limpo = texto_resposta.strip()
    # Remove blocos de código markdown
    if texto_limpo.startswith("```json"):
        texto_limpo = texto_limpo[7:]
    if texto_limpo.startswith("```"):
        texto_limpo = texto_limpo[3:]
    if texto_limpo.endswith("```"):
        texto_limpo = texto_limpo[:-3]
    texto_limpo = texto_limpo.strip()
    
    # Tenta encontrar o JSON dentro do texto se ainda não for JSON válido
    if not texto_limpo.startswith("{"):
        inicio = texto_limpo.find("{")
        if inicio != -1:
            fim = texto_limpo.rfind("}") + 1
            if fim > inicio:
                texto_limpo = texto_limpo[inicio:fim]
    
    return texto_limpo


def extrair_com_llama(texto: str) -> dict:
    """
    Usa Llama para FILTRAR conversa irrelevante e extrair informações clínicas.
    
    Etapa 1: O prompt instrui o modelo a ignorar conversa casual
    Etapa 2: Extrai apenas dados clinicamente relevantes para o prontuário
    """
    if not LLAMA_OK:
        raise HTTPException(500, "Ollama não instalado. Use: pip install ollama")
    
    print("🤖 Enviando para Llama (com filtragem inteligente)...")
    
    prompt = f"""Você é um assistente veterinário especializado em prontuários clínicos.
Sua tarefa é analisar a transcrição de uma consulta veterinária e extrair APENAS informações clinicamente relevantes.

═══════════════════════════════════════════════
REGRAS DE FILTRAGEM (MUITO IMPORTANTE):
═══════════════════════════════════════════════

IGNORE COMPLETAMENTE e NÃO inclua no prontuário:
- Saudações e despedidas ("oi", "bom dia", "tchau", "obrigado")
- Conversas pessoais entre veterinário e tutor (sobre família, trabalho, clima, trânsito)
- Comentários casuais sobre o animal que NÃO sejam clínicos ("que lindo", "ele é sapeca")
- Piadas, risadas, interjeições
- Comentários sobre preços, pagamento ou agendamento
- Qualquer assunto que NÃO seja sobre a saúde/condição clínica do animal

EXTRAIA APENAS:
- Dados de identificação do tutor (nome, CPF, telefone, email, endereço)
- Dados do animal (nome, espécie, raça, idade, sexo, peso)
- Informações clínicas: queixa, sintomas, histórico, comportamentos alterados
- Dados do exame físico: temperatura, FC, FR, mucosas, palpação
- Diagnóstico, exames, tratamento, medicamentos
- Observações e recomendações CLÍNICAS

═══════════════════════════════════════════════
TRANSCRIÇÃO DA CONSULTA:
═══════════════════════════════════════════════
{texto}

═══════════════════════════════════════════════
INSTRUÇÕES DE RESPOSTA:
═══════════════════════════════════════════════

Retorne SOMENTE um JSON válido (sem explicações, sem markdown, sem texto antes ou depois).
Use null para campos não mencionados na parte clínica da conversa.
Para campos de texto, escreva de forma profissional e resumida.
Para listas, inclua apenas itens clinicamente relevantes.

{{
  "tutor_nome": "nome completo ou null",
  "tutor_cpf": "CPF ou null",
  "tutor_telefone": "telefone ou null",
  "tutor_email": "email ou null",
  "tutor_endereco": "endereço ou null",
  "animal_nome": "nome do animal ou null",
  "animal_especie": "Canino/Felino/Ave/etc ou null",
  "animal_raca": "raça ou null",
  "animal_idade": "idade ou null",
  "animal_sexo": "Macho/Fêmea ou null",
  "animal_peso": 0.0,
  "queixa_principal": "resumo objetivo da queixa principal ou null",
  "historico_doenca": "histórico clínico relevante ou null",
  "sintomas": ["sintoma1", "sintoma2"],
  "comportamento": ["alteração comportamental 1"],
  "temperatura": 0.0,
  "frequencia_cardiaca": 0,
  "frequencia_respiratoria": 0,
  "mucosas": "descrição clínica ou null",
  "palpacao_abdominal": "achados ou null",
  "suspeita_diagnostica": "hipótese diagnóstica ou null",
  "exames_solicitados": ["exame1", "exame2"],
  "tratamento_prescrito": "descrição do tratamento ou null",
  "medicamentos": ["medicamento 1 - dose - via - frequência"],
  "observacoes_gerais": "observações clínicas relevantes ou null",
  "recomendacoes": "recomendações ao tutor ou null"
}}"""

    try:
        # Verifica se Ollama está rodando
        try:
            ollama.list()
            print("✅ Ollama conectado")
        except Exception as e:
            print(f"❌ Ollama não está rodando: {e}")
            raise HTTPException(500, "Ollama não está rodando. Execute: ollama serve")
        
        # Primeira tentativa
        response = ollama.chat(
            model='llama3',
            messages=[{'role': 'user', 'content': prompt}]
        )
        
        texto_resposta = response['message']['content']
        print(f"🤖 Resposta do Llama ({len(texto_resposta)} chars)")
        print(f"Primeiros 300 chars: {texto_resposta[:300]}")
        
        texto_limpo = _limpar_json_response(texto_resposta)
        
        print("🔍 Tentando fazer parse do JSON...")
        try:
            dados = json.loads(texto_limpo)
            print("✅ JSON parseado com sucesso!")
            return dados
        except json.JSONDecodeError as e:
            print(f"⚠️ Falha no parse (1ª tentativa): {str(e)}")
            print(f"Texto: {texto_limpo[:300]}")
            
            # Segunda tentativa com prompt simplificado
            print("🔄 Tentando novamente com prompt simplificado...")
            retry_prompt = f"""A resposta anterior não foi um JSON válido. 
Por favor, retorne APENAS o JSON puro, sem nenhum texto adicional, sem markdown.
Baseado nesta transcrição veterinária, preencha o JSON:

{texto}

Responda SOMENTE com o JSON, começando com {{ e terminando com }}."""
            
            retry_response = ollama.chat(
                model='llama3',
                messages=[
                    {'role': 'user', 'content': prompt},
                    {'role': 'assistant', 'content': texto_resposta},
                    {'role': 'user', 'content': retry_prompt}
                ]
            )
            
            retry_texto = retry_response['message']['content']
            retry_limpo = _limpar_json_response(retry_texto)
            
            try:
                dados = json.loads(retry_limpo)
                print("✅ JSON parseado na 2ª tentativa!")
                return dados
            except json.JSONDecodeError:
                print("❌ Falha na 2ª tentativa também")
                return {
                    "observacoes_gerais": texto_resposta,
                    "erro_parse": True
                }
    
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Erro ao processar com Llama: {str(e)}")
        traceback.print_exc()
        raise HTTPException(500, f"Erro ao processar com Llama: {str(e)}")

# Endpoints
@app.get("/health")
async def health():
    ollama_running = False
    try:
        ollama.list()
        ollama_running = True
    except:
        pass
    
    return {
        "status": "healthy",
        "whisper": WHISPER_OK,
        "llama": LLAMA_OK,
        "ollama_running": ollama_running
    }

@app.get("/prontuarios")
async def listar_prontuarios():
    return prontuarios_db

@app.get("/prontuarios/{prontuario_id}")
async def obter_prontuario(prontuario_id: int):
    for p in prontuarios_db:
        if p["id"] == prontuario_id:
            return p
    raise HTTPException(404, "Prontuário não encontrado")

@app.post("/prontuarios")
async def criar_prontuario(dados: ProntuarioRequest):
    global prontuario_counter
    prontuario_counter += 1
    prontuario = {
        "id": prontuario_counter,
        **dados.dict(),
        "data_atendimento": datetime.now().isoformat(),
    }
    prontuarios_db.append(prontuario)
    return prontuario

@app.put("/prontuarios/{prontuario_id}")
async def atualizar_prontuario(prontuario_id: int, dados: ProntuarioRequest):
    for i, p in enumerate(prontuarios_db):
        if p["id"] == prontuario_id:
            prontuarios_db[i] = {**p, **dados.dict(exclude_unset=True)}
            return prontuarios_db[i]
    raise HTTPException(404, "Prontuário não encontrado")

@app.delete("/prontuarios/{prontuario_id}")
async def deletar_prontuario(prontuario_id: int):
    global prontuarios_db
    prontuarios_db = [p for p in prontuarios_db if p["id"] != prontuario_id]
    return {"ok": True}

@app.get("/internacoes")
async def listar_internacoes():
    return internacoes_db

@app.post("/internacoes")
async def criar_internacao(dados: InternacaoRequest):
    global internacao_counter
    internacao_counter += 1
    internacao = {
        "id": internacao_counter,
        **dados.dict(),
        "data_internacao": datetime.now().isoformat(),
        "registros": [],
    }
    internacoes_db.append(internacao)
    return internacao

@app.post("/internacoes/{internacao_id}/registros")
async def adicionar_registro(internacao_id: int, dados: RegistroRequest):
    for intern in internacoes_db:
        if intern["id"] == internacao_id:
            registro = {
                "id": len(intern["registros"]) + 1,
                **dados.dict(),
                "hora": datetime.now().isoformat(),
            }
            intern["registros"].append(registro)
            return registro
    raise HTTPException(404, "Internação não encontrada")

@app.put("/internacoes/{internacao_id}/status")
async def atualizar_status(internacao_id: int, status: str):
    for intern in internacoes_db:
        if intern["id"] == internacao_id:
            intern["status"] = status
            return intern
    raise HTTPException(404, "Internação não encontrada")

@app.post("/transcrever")
async def transcrever(file: UploadFile = File(...)):
    """
    Transcreve áudio e extrai informações usando Whisper + Llama
    """
    try:
        print("\n" + "="*60)
        print("🎙️ NOVA REQUISIÇÃO DE TRANSCRIÇÃO")
        print("="*60)
        
        print(f"📁 Arquivo: {file.filename}")
        print(f"📝 Content-Type: {file.content_type}")
        
        content = await file.read()
        print(f"📊 Tamanho: {len(content)} bytes ({len(content)/1024:.1f} KB)")
        
        # 1. Transcrever
        print("\n🎤 ETAPA 1: Transcrição com Whisper")
        texto = transcrever_audio(content)
        
        # 2. Extrair informações com Llama
        print("\n🤖 ETAPA 2: Extração com Llama")
        prontuario = extrair_com_llama(texto)
        
        print("\n✅ SUCESSO!")
        print("="*60 + "\n")
        
        return {
            "sucesso": True,
            "texto": texto,
            "prontuario": prontuario,
            "audio_duracao": len(content) / 16000
        }
    
    except HTTPException:
        raise
    except Exception as e:
        print(f"\n❌ ERRO GERAL: {str(e)}")
        traceback.print_exc()
        raise HTTPException(500, f"Erro inesperado: {str(e)}")

if __name__ == "__main__":
    print("=" * 60)
    print("🐾 AnimaListen Pro - Backend com NLP")
    print("=" * 60)
    print(f"🎤 Whisper: {'✅' if WHISPER_OK else '❌ pip install openai-whisper'}")
    print(f"🤖 Llama: {'✅' if LLAMA_OK else '❌ pip install ollama'}")
    
    # Testa se Ollama está rodando
    if LLAMA_OK:
        try:
            ollama.list()
            print("🟢 Ollama: Rodando")
        except:
            print("🔴 Ollama: NÃO está rodando (execute: ollama serve)")
    
    print("🌐 http://127.0.0.1:8000")
    print("=" * 60)
    uvicorn.run(app, host="127.0.0.1", port=8000)